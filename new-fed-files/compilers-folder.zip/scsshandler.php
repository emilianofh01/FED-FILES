<?php 
error_reporting(0);
header("Access-Control-Allow-Origin: *");
require_once "scss/scss.inc.php";
use Leafo\ScssPhp\Compiler;




$path = $_POST['path'];
try{
	$scss = new Compiler();
	$scss->setImportPaths($path);
	$scss->setFormatter("Leafo\ScssPhp\Formatter\Compressed");
	$csscode = $scss->compile('@import "styles.scss";');

	$fichero = $path.'styles.css';
	$actual = $csscode;
	file_put_contents($fichero, $actual);
	echo "Compliacion correcta!";
} catch (exception $e) {
	echo "Error: " . $e->getMessage();
}

?>
