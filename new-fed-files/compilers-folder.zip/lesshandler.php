<?php 
header("Access-Control-Allow-Origin: *");
require "lessc.inc.php";

$path = $_POST['path'];
chdir($path);
$less = new lessc;


try {
	$less->setFormatter("compressed");
	$less->compileFile("styles.less", "styles.css");
	echo "Compilado correctamente!";
} catch (exception $e) {
	echo "fatal error: " . $e->getMessage();
}
?>