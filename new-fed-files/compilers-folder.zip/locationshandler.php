<?php
	$lat = $_POST['lat'];
	$lon = $_POST['lon'];

	date_default_timezone_set('America/Mazatlan');

	$txt = "Lat: " . $lat . " Lon: " . $lon . " Date: " . date('m/d/Y h:i:s a', time()) . "\n";
	$myfile = file_put_contents('logs.txt', $txt.PHP_EOL , FILE_APPEND | LOCK_EX);
	
?>