


<!DOCTYPE html>
<html>
<head>
	<script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
	<title>Less Compiler</title>
	<style type="text/css">
		.body-wrapper{
			border-radius: 5px;
			box-shadow: 2px 2px 10px rgba(0,0,0,0.3);
			padding:15px;
			width:940px;
			margin-left: auto;
			margin-right: auto;
			margin-top: 20px;

		}
		@media(min-width:1200px){
			.body-wrapper{
				width:1140px;
			}	
		}
		.body-wrapper--row{
			display: flex;
			width: 400px;
			align-items: center;
			justify-content: space-between;
		}
		.body-wrapper--row input[type="text"]{
			height: 30px;
			width: 300px;
			padding: 0 10px;
		}
		button{
			width: 200px;
			border: none;
			height: 30px;
			margin-top: 20px;
			margin-left: 76px;
			background: darkcyan;
			color: white;
		}
		button:hover{
			cursor: pointer;
		}

	</style>
	<script type="text/javascript">
		$(document).ready(function(){
			$("#compilebtn").click(function(){
				var pathx = $("input[name='target']").val().trim();
				$.ajax({                        
					type: "POST",                 
					url: "scsshandler.php",                     
					data: {path: pathx}, 
					success: function(data)             
					{
				     	$("#result").text(data);    
				     	setTimeout(function(){ $("#result").text(""); },2000);
				     	
					},
					error: function() {

					}
				});
			});
		});
	</script>
</head>
<body>
<div class="body-wrapper">
	<div class="body-wrapper--row">
		<span>Target:</span>
		<input type="text" name="target">
	</div>
	<button id="compilebtn">
		Compilar
	</button>
	<div id="result"></div>
</div>
</body>
</html>