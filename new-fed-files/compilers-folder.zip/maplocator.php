<!DOCTYPE html>
<html>
  <head>
    <script src="https://code.jquery.com/jquery-3.2.1.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyApkt7TG35f1iAqfkAFRYZ8psHMeHlQJYY&callback=initMap">
    </script>
    <title>Location Demo - by Nava</title>
    <link href="https://fonts.googleapis.com/css?family=Montserrat:300%7COpen+Sans+Condensed:300|Patua+One" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <style>
      body{
        margin: 0;
        background-color: #f5f5f5;
      }
      #map {
        width:100%;height:400px;
        background-color: #d0d0d0;
        margin-bottom: 30px;
      }
      h3{
        margin: 0;
        padding: 30px 10px;
        text-align: left;
        font-family: Montserrat;
        background-color: #f5f5f5;
        color: #333;
        font-weight: 300;
      }
      p{
        color:#333;
        font-family: Montserrat;
        padding-left: 10px;
        padding-right: 10px;
        line-height: 1.2;
      }
      header.header{
        padding:15px;
        position: relative;
        background: #222;
      }
      .logo-col{
        position: absolute;
        top:15px;
        left: 15px;
      }
      ul.menu{
        list-style: none;
        display: flex;
        flex-direction: column;
        align-items: flex-end;
        font-family: Montserrat;
        padding: 0;
      }
      ul.menu li{
        line-height: 1.4;
      }
      ul.menu a{
        color:#fff;
        text-decoration: none;

      }
      a#login{
        display: none;
      }
      button#send-correct{
        transition:all ease-in-out 0.2s;
        width: 90%;
        margin-left: auto;
        margin-right: auto;
        display: block;
        border: none;
        height: 50px;
        font-family: Montserrat;
        font-size: 18px;
        background-color: #088A85;
        color:#fff;
        border-radius: 5px;
        margin-top: 50px;
        margin-bottom: 50px;
      }
      

      button#send-correct:hover,
      button#send-correct:focus,
      button#send-correct:active{
        outline:none;
        opacity: 0.8;
        cursor: pointer;
      }

    </style>
    <script type="text/javascript">

     
      var map;
      var latitud = -1;
      var longitud = -1;
      function initMap() {
        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(showPosition);
        } else {
        }
      }
      function showPosition(position) {
        var latx = position.coords.latitude;
        var lonx = position.coords.longitude;

        latitud = latx;
        longitud = lonx;

         $.ajax({
            method: "POST",
            url: "locationshandler.php",
            data: { lat: latitud, lon: longitud },
            success: function(data){

            }
          });

        map = new google.maps.Map(document.getElementById('map'), {
          center: {lat: latx, lng: lonx},
          zoom: 13
        });
        var marker = new google.maps.Marker({
          position: {lat: latx, lng: lonx},
          map: map,
          title: 'Tu Ubicacion'
        });
        
      }


      $(document).ready(function(){
         $("#send-correct").click(function(e){
            e.preventDefault();
            e.stopPropagation();
            $.ajax({
              method: "POST",
              url: "locationshandler.php",
              data: { lat: latitud, lon: longitud },
              success: function(data){
                alert("¡Gracias por su cooperacion!");

              }
            });

         });
      });
   
    </script>
  </head>
  <body >
    <?php
    $path = $_SERVER['DOCUMENT_ROOT'];
    $path .= "/incfiles/header.php";
    include_once($path); 
    ?>
    <h3>Prueba de Ubicación</h3>
     <p>Esta es una prueba para medir la efectividad del servicio de ubicación de Google Maps ofrecido por <strong>Web n Dev</strong>. Recuerda activar los servicios de <strong>GPS</strong>.</p>
    <div id="map">
    </div>
   
    <p>¿Fue preciso el servicio de ubicación proporcionado por <strong>Web n Dev</strong>?</p>
    <button id="send-correct">
      Aceptar
    </button>
  </body>
  <?php
  $path = $_SERVER['DOCUMENT_ROOT'];
  $path .= "/incfiles/footer.php";
  include_once($path); 
  ?>
</html>

